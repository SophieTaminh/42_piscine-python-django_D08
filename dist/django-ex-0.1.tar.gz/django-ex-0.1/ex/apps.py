from django.apps import AppConfig


class ExConfig(AppConfig):
    name = 'ex'
