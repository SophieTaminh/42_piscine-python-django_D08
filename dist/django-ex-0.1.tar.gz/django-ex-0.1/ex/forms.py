from django import forms
from django.forms import ModelForm
from ex.models import File


class FileForm(forms.ModelForm):
	class Meta:
		model = File
		fields =['name','file']
	